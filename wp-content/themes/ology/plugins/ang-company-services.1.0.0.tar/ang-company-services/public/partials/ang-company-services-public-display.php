<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       http://torbara.com
 * @since      1.0.0
 *
 * @package    Ang_Company_Services
 * @subpackage Ang_Company_Services/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
