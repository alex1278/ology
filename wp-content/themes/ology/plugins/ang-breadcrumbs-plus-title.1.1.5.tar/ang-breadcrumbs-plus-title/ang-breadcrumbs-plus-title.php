<?php
/*
  Plugin Name:  ANG Breadcrumbs & Title
  Plugin URI:   http://themeforest.net/user/torbara/?ref=torbara
  Description:  Display your site breadcrumb navigation with page title.
  Author:       Aleksandr Glovatskyy
  Version:      1.1.5
  Last Update:  24.03.2016
  Author URI:   http://themeforest.net/user/torbara/portfolio/?ref=torbara
 */

class ANG_Breadcrumbs_And_Title extends \WP_Widget
{
/*
 * Register widget with WordPress.
 */
    public function __construct()
    {
        $widget_ops = array('description' => 'Display your sites breadcrumb navigation with page title');
        parent::__construct(false, __('ANG Breadcrumbs & Title', 'ang-plugins'), $widget_ops);
    }

    public function widget($args, $instance)
    {
        wp_reset_postdata(); //reset WP-Query data if nore then one Wp_query affects on page.
        global $wp_query;
        $output_page_title = "";
        extract($args);

        $title = $instance['title'];
        $home_title = trim($instance['home_title']);
        $title_no = $instance['title_no'];
        $bread_position = $instance['bread_position'];

        if (empty($home_title)) {
            $home_title = 'Home';
            $output_page_title = "";
        }

        echo $before_widget;

        if ($title) {
            echo $before_title . $title . $after_title;
            }

        if (!is_home() && !is_front_page()) {

            $output = '<ul class="uk-breadcrumb">';
            $output_title ="";
            $output_page_title = "";

            $output .= '<li><a href="'.get_option('home').'">'.$home_title.'</a></li>';
//            $output .= '<li><a href="'.esc_url( home_url( '/' ) ).'">'.$home_title.'</a></li>';

            if (is_single()) {
                if ($cats = get_the_category()) {
                    $cat = $cats[0];

                    if (is_object($cat)) {
                        if ($cat->parent != 0) {
                            $cats = explode("@@@", get_category_parents($cat->term_id, true, "@@@"));

                            unset($cats[count($cats)-1]);
                            $output .= str_replace('<li>@@','<li>', '<li>'.implode("</li><li>", $cats).'</li>');
                        } else {
                            $output .= '<li><a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a></li>';
                        }
                    }
                }
            }

            if (is_category()) {

                $cat_obj = $wp_query->get_queried_object();

                $cats = explode("@@@", get_category_parents($cat_obj->term_id, TRUE, '@@@'));

                unset($cats[count($cats)-1]);

                $cats[count($cats)-1] = '@@<span>'.strip_tags($cats[count($cats)-1]).'</span>';

                $output_page_title = '<h1>'.single_cat_title('',false).'</h1>';
                $output_title = '<h2>'.single_cat_title('',false).'</h2>';

                $output .= str_replace('<li>@@','<li class="uk-active">', '<li>'.implode("</li><li>", $cats).'</li>');
            } elseif (is_tag()) {

                $output_page_title = '<h1>'.single_cat_title('',false).'</h1>';
                $output_title = '<h2>'.single_cat_title('',false).'</h2>';

                $output .= '<li class="uk-active"><span>'.single_cat_title('',false).'</span></li>';
            } elseif (is_date()) {

                $output_page_title = '<h1>'.single_month_title(' ',false).'</h1>';
                $output_title = '<h2>'.single_month_title(' ',false).'</h2>';

                $output .= '<li class="uk-active"><span>'.single_month_title(' ',false).'</span></li>';
            } elseif (is_author()) {

                //$user = !empty($wp_query->query_vars['author_name']) ? get_user_by('login', $wp_query->query_vars['author_name']) : get_user_by("id", ((int) $_GET['author']));
                if(isset($_GET['author_name'])) {
                    $user = get_user_by('login', $wp_query->query_vars['author_name']);
                } elseif(isset($_GET['author'])) {
                    $user = get_user_by("id", ((int) $_GET['author']));
                } else {
                    $user = get_user_by('ID', get_the_author_meta('ID'));
                }

                $output_page_title = '<h1>'.$user->display_name.'</h1>';
                $output_title = '<h2>'.$user->display_name.'</h2>';
                $output .= '<li class="uk-active"><span>'.$user->display_name.'</span></li>';
            } elseif (is_search()) {

                $output_page_title = '<h1>'.stripslashes(strip_tags(get_search_query())).'</h1>';
                $output_title = '<h2>'.stripslashes(strip_tags(get_search_query())).'</h2>';

                $output .= '<li class="uk-active"><span>'.stripslashes(strip_tags(get_search_query())).'</span></li>';
            } elseif (is_tax()) {

                $taxonomy = get_taxonomy (get_query_var('taxonomy'));
                $term = get_query_var('term');

                $output_page_title = '<h1>'.$taxonomy->label .': '.$term.'</h1>';
                $output_title = '<h2>'.$taxonomy->label .': '.$term.'</h2>';

                $output .= '<li class="uk-active"><span>'.$taxonomy->label .': '.$term.'</span></li>';
            } elseif (is_archive()) {




                //custom post type archive
                if(is_post_type_archive()){
                    // woocommerce shop page
                if (is_plugin_active("woocommerce/woocommerce.php") && is_shop()) {
                    $title = wc_get_page_id( 'shop' ) ? get_the_title( wc_get_page_id( 'shop' ) ) : '';
                    $output_page_title = '<h1>'.$title.'</h1>';
                    $output_title = '<h1>'.$title.'</h1>';

                    $output .= '<li class="uk-active"><span>'.$title.'</span></li>';
                }else{
                    $post_type = get_post_type_object( get_post_type() );
                    $output .= '<li class="uk-active"><span>'.$post_type->label.'</span></li>';
                        $output_page_title = '<h1>'.$post_type->label.'</h1>';
                        $output_title = '<h2>'.$post_type->label.'</h2>';
                    }
                }

                // easy property listing post types
            }elseif (is_singular(array('property', 'land', 'rental', 'commercial', 'business', 'commercial_land', 'rural')) ){
                if (is_plugin_active("easy-property-listings/easy-property-listings.php")) {
                    $output .= '<li><a href="'.get_post_type_archive_link( get_post_type() ).'">'.get_post_type().'</a></li>';
                    //$output .= '<li class="uk-active">'.get_post_type().'</li>';

                    $title = ang_get_property_heading();

                    $output_page_title = '<h1>'.$title.'</h1>';
                    $output_title = '<h2>'.$title.'</h2>';

                    $output .= '<li class="uk-active"><span>'.$title.'</span></li>';
                }
            }else {

                $ancestors = get_ancestors(get_the_ID(), 'page');
                for($i = count($ancestors)-1; $i >= 0; $i--) {
                    $output .= '<li><a href="'.get_page_link($ancestors[$i]).'" title="'.get_the_title($ancestors[$i]).'">'.get_the_title($ancestors[$i]).'</a></li>';
                }

                $output_page_title = '<h1>'.get_the_title().'</h1>';
                $output_title = '<h1>'.get_the_title().'</h1>';

                $output .= '<li class="uk-active"><span>'.get_the_title().'</span></li>';
            }

            $output .= '</ul>';
        } else {
//            $output_page_title = '<h1>'.$home_title.'</h1>';

            $output = '<ul class="uk-breadcrumb">';
            $output .= '<li class="uk-active"><span>'.$home_title.'</span></li>';

            $output .= '</ul>';

        }

//        echo $output;

           if($instance['title_no']=="1") {
               switch ($instance['bread_position']) {
                    case 1:
                        echo '<div class="uk-grid uk-grid-small ang-title-crumbs" data-uk-grid-margin><div class="uk-width-medium-1-1"><div class="ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div></div><div class="uk-width-medium-1-1">'.$output_page_title.'</div></div>';
                        break;
                    case 2:
                        echo '<div class="uk-grid uk-grid-small ang-title-crumbs" data-uk-grid-margin><div class="uk-width-medium-1-1">'.$output_page_title.'</div><div class="uk-width-medium-1-1"><div class="ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div></div></div>';
                        break;
                    case 3:
                        echo '<div class="uk-grid uk-grid-small ang-title-crumbs" data-uk-grid-margin><div class="uk-width-medium-1-2"><div class="ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div></div><div class="uk-width-medium-1-2">'.$output_page_title.'</div></div>';
                        break;
                    case 4:
                        echo '<div class="uk-grid uk-grid-small ang-title-crumbs" data-uk-grid-margin><div class="uk-width-medium-1-2">'.$output_page_title.'</div><div class="uk-width-medium-1-2"><div class="uk-float-right ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div></div></div>';
                        break;
                    default:
                        echo '<div class="uk-grid uk-grid-small ang-title-crumbs" data-uk-grid-margin><div class="uk-width-medium-1-2">'.$output_page_title.'</div><div class="uk-width-medium-1-2"><div class="uk-float-right ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div></div></div>';
                        break;
               }
        } else {
            echo '<div class="ang-breadcrumbs-output '.$instance[ 'ex_class' ].'">'.$output.'</div>';
        }

    wp_reset_query();

         echo $after_widget;
    }

    public function update($new_instance, $old_instance){
        $instance = $old_instance;
        $instance['title'] 	= $new_instance['title'];
        $instance['home_title'] = $new_instance['home_title'];
        $instance['ex_class'] = $new_instance['ex_class'];
        $instance['title_no'] 	= $new_instance['title_no'];
        $instance['bread_position'] 	= $new_instance['bread_position'];

        return $new_instance;
    }

    public function form($instance) {
        $title = isset($instance['title']) ? esc_attr($instance['title']) : 'Breadcrumbs';
        $home_title = isset($instance['home_title']) ? esc_attr($instance['home_title']) :'Home';
        ?>

        <!--enter widget title-->
        <p>
            <label for="<?php echo $this->get_field_id('title') ?>"><?php esc_html_e('Title:', 'ang-plugins');?></label>
            <input type="text" name="<?php echo $this->get_field_name('title') ?>"  value="<?php echo $title; ?>" class="widefat" id="<?php echo $this->get_field_id('title') ?>">
        </p>

        <!--enter home page title-->
        <p>
            <label for="<?php echo $this->get_field_id('home_title') ?>"><?php esc_html_e('Home title:', 'ang-plugins');?></label>
            <input type="text" placeholder="Home" name="<?php echo $this->get_field_name('home_title') ?>"  value="<?php echo $home_title ?>" class="widefat" id="<?php echo $this->get_field_id('home_title') ?>">
        </p>

        <?php $ex_class = isset( $instance[ 'ex_class' ] ) ? $instance[ 'ex_class' ] : ''; ?>
        <p>
            <label for="<?php echo $this->get_field_id('ex_class'); ?>">
                <?php esc_html_e( 'Extra class:', 'ang-plugins'); ?>
                <input class="widefat"
                        id="<?php echo $this->get_field_id('ex_class'); ?>"
                        name="<?php echo $this->get_field_name('ex_class'); ?>"
                        type="text"
                        value="<?php echo $ex_class; ?>" />
            </label>
        </p>

    <!--checkbox disable page title-->

        <?php $title_no = isset( $instance['title_no'] ) ? $instance['title_no'] : "1"; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'title_no' )); ?>">
                <?php esc_html_e('Disable page title:', 'ang-plugins');?>
            </label>
            <br>
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('title_no')."_1"); ?>" name="<?php echo esc_attr($this->get_field_name('title_no')); ?>" value="1" <?php if($title_no=="1"){ echo "checked"; }?>><?php _e( 'No' ); ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('title_no')."_2"); ?>" name="<?php echo esc_attr($this->get_field_name('title_no')); ?>" value="2" <?php if($title_no=="2"){ echo "checked"; }?>><?php _e( 'Yes' ); ?>
        </p>

        <!--checkbox select breadcrumbs position-->
        <?php $bread_position = isset( $instance['bread_position'] ) ? $instance['bread_position'] : "1"; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'bread_position' )); ?>">
                <?php esc_html_e('Breadcrumbs position:', 'ang-plugins');?>
            </label>
            <br>
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('bread_position')."_1"); ?>" name="<?php echo esc_attr($this->get_field_name('bread_position')); ?>" value="1" <?php if($bread_position=="1"){ echo "checked"; }?>><?php _e( 'Top' ); ?> &nbsp;&nbsp;
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('bread_position')."_2"); ?>" name="<?php echo esc_attr($this->get_field_name('bread_position')); ?>" value="2" <?php if($bread_position=="2"){ echo "checked"; }?>><?php _e( 'Bottom' ); ?> &nbsp;&nbsp;
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('bread_position')."_3"); ?>" name="<?php echo esc_attr($this->get_field_name('bread_position')); ?>" value="3" <?php if($bread_position=="3"){ echo "checked"; }?>><?php _e( 'Left' ); ?> &nbsp;&nbsp;
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('bread_position')."_4"); ?>" name="<?php echo esc_attr($this->get_field_name('bread_position')); ?>" value="4" <?php if($bread_position=="4"){ echo "checked"; }?>><?php _e( 'Right' ); ?>
        </p>

        <?php
    }
}

add_action('widgets_init', create_function('', 'return register_widget("ANG_Breadcrumbs_And_Title");'));

//unregister default Warp Breadcrumbs
function ang_deregister_widget() {
    unregister_widget( 'Warp_Breadcrumbs' );
}
add_action( 'widgets_init', 'ang_deregister_widget', 11 );


// Additional links in plugin settings: Torbara.com | Portfolio
$tt_f_plugin_links = function($links) {
    array_push($links, '<a title="We are developing beautiful themes and applications for the web!" href="http://torbara.com" target="_blank" style="font-weight: bold; font-size: 14px;"><img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NTMuNSA0NTMuNSI+PHBhdGggZD0iTTM5NC43IDIzOC4zOTJjLTEuNSAwLTMgLjMtNC40LjdsLTUwLjEtMTEwYzMuOS0yLjQgNi41LTYuNyA2LjUtMTEuNiAwLTYuNi00LjctMTIuMS0xMC45LTEzLjQtLjYtLjEtMS4xLS4yLTEuNy0uMmgtMWMtNC43IDAtOC44IDIuMy0xMS4zIDUuOWwtNzcuNi0zMi41Yy4xLS43LjItMS40LjItMi4xIDAtNy42LTYuMS0xMy43LTEzLjctMTMuN3MtMTMuNyA2LjEtMTMuNyAxMy43di4zbC04OS40IDMwLjNjLTIuMS00LjktNi45LTguMy0xMi42LTguMy03LjUgMC0xMy43IDYuMS0xMy43IDEzLjcgMCA0LjkgMi42IDkuMiA2LjUgMTEuNmwtNDUuNiA4NS45Yy0uNS0uMS0xLS4xLTEuNi0uMS00LjUgMC04LjQgMi4xLTEwLjkgNS41LTEgMS4zLTEuNyAyLjctMi4yIDQuMy0uNCAxLjItLjYgMi42LS42IDMuOSAwIDcuNiA2LjEgMTMuNyAxMy43IDEzLjdoLjJsNDIuNiA5NS43Yy0yLjYgMi41LTQuMyA2LTQuMyA5LjkgMCA3LjUgNi4xIDEzLjcgMTMuNyAxMy43IDQuNyAwIDguOC0yLjMgMTEuMy01LjlsODYuNSAzOS41Yy41IDcuMSA2LjQgMTIuNiAxMy42IDEyLjYgNy41IDAgMTMuNi02IDEzLjctMTMuNWw5NC44LTMxLjJjMi40IDMuOSA2LjcgNi41IDExLjcgNi41IDcuNSAwIDEzLjctNi4xIDEzLjctMTMuNyAwLTUuNS0zLjMtMTAuMy04LTEyLjVsMzguNi03M2MxLjguOSAzLjkgMS41IDYuMiAxLjUgNy41IDAgMTMuNy02LjEgMTMuNy0xMy43LS4yLTcuNC02LjMtMTMuNS0xMy45LTEzLjV6bS03NC45LTEyNC4zYy0uMyAxLjEtLjQgMi4yLS40IDMuNCAwIDQuNCAyLjEgOC40IDUuNCAxMC45bC0xNi41IDQzLjNjLS44LS4yLTEuNy0uMi0yLjYtLjItMi4xIDAtNCAuNS01LjggMS4zbC01Ni42LTkwLjYgNzYuNSAzMS45em02MS40IDEzOS45bC02MS40IDMxLjhjLTIuNC0yLjEtNS42LTMuNC05LTMuNGgtMWwtMy4zLTgzLjZjMy4zLS4yIDYuMy0xLjYgOC42LTMuN2w2Ni4xIDU1LjNjLS4xLjUtLjEgMS4xLS4xIDEuNiAwIC43IDAgMS4zLjEgMnptLTI1NC45LTEzLjVsMTEtNTguN2guMmMyIDAgNC0uNSA1LjctMS4zbDU0LjggMTA1LjguMi0uMWMtLjEuMS0uMS4yLS4yLjNsLTYwLjctMjcuNi0yLjQtMS4xYy4xLS4zLjItLjcuMy0xIC4zLTEuMS40LTIuMy40LTMuNC4yLTYtMy44LTExLjEtOS4zLTEyLjl6bTIwLjktNjIuOGMxLjQtMS40IDIuNS0zLjEgMy4yLTVsNTkuNyAyLjNjLjYgNS43IDQuNyAxMC40IDEwLjIgMTEuOGwtMTEuNCA5MS45Yy0yLjkuMy01LjUgMS42LTcuNSAzLjRsLTU0LjItMTA0LjR6bTY2LjUgMTAxLjNsMTEuNC05MS44YzQuOS0uNSA5LjEtMy42IDExLThsNTYuMSAzLjJjLS4yLjktLjMgMS44LS4zIDIuNyAwIDQgMS43IDcuNyA0LjUgMTAuMmwtODIuNSA4My44LS40LjQuMi0uNXptODUuMi03OS4ybDEuOC0xLjkuOS4zLjEgMi42IDMuMiA4Mi44Yy0zLjQgMS42LTYuMSA0LjYtNy4yIDguMmgtNzMuNWMtLjEtNC40LTIuMy04LjItNS42LTEwLjZsODAuMy04MS40em0tNjguNS0xMTAuOWguMmMzLjQgMCA2LjYtMS4zIDktMy40bDU2LjMgOTAuMWMtLjYuNy0xLjIgMS40LTEuNyAyLjJsLTU2LjgtMy4zdi0uOGMwLTUuMy0zLjEtOS45LTcuNS0xMi4ybC41LTcyLjZ6bS01LjYtMS4zYy4yLjEuNS4yLjguM2wtLjUgNzIuMWMtLjQgMC0uOS0uMS0xLjMtLjEtNi40IDAtMTEuOCA0LjQtMTMuMyAxMC4zbC01OS4zLTIuM2MtLjEtMy41LTEuNC02LjctMy42LTlsNzcuMi03MS4zem0tOTYuMSAyMy42di0uN2w4OS4zLTMwLjNjLjcgMS43IDEuNyAzLjIgMi45IDQuNWwtNzcuMiA3MS4yYy0xLjgtLjktMy45LTEuNS02LjItMS41LTEuMSAwLTIuMS4xLTMuMS40bC0xMS0zMi44YzMuMi0yLjUgNS4zLTYuNCA1LjMtMTAuOHptLTE2LjQgMTMuNGMuOS4yIDEuOC4zIDIuNy4zIDEuNCAwIDIuOC0uMiA0LjEtLjZsMTAuOSAzMi40Yy0zLjcgMi40LTYuMSA2LjYtNi4xIDExLjQgMCA1LjggMy42IDEwLjcgOC43IDEyLjdsLTExIDU5Yy00LjEuMi03LjggMi4xLTEwLjEgNS4xbC0zNy43LTE4LjhjLjQtMS4yLjUtMi41LjUtMy44IDAtNS4zLTMtOS45LTcuNC0xMi4xbDQ1LjQtODUuNnptMiAyMDMuNWMtLjUgMC0uOS0uMS0xLjQtLjEtMS45IDAtMy43LjQtNS4zIDEuMWwtNDEuOS05NGMyLjQtLjkgNC40LTIuNSA1LjktNC42bDM3LjUgMTguN2MtLjQgMS4zLS43IDIuOC0uNyA0LjMgMCA2LjEgNCAxMS4yIDkuNCAxM2wtMy41IDYxLjZ6bTkuMyA1LjFjLTEuMi0xLjYtMi44LTIuOS00LjYtMy43bDMuNi02Mi4zYzQtLjIgNy42LTIuMSAxMC01bDY0LjMgMjkuMXYxYzAgMS4yLjIgMi40LjUgMy41bC03My44IDM3LjR6bTg3LjYgNTAuN2wtODUtMzguOGMuMy0xLjEuNC0yLjIuNC0zLjQgMC0xLjUtLjItMi45LS43LTQuMmw3My41LTM3LjNjMi41IDMuNSA2LjYgNS44IDExLjIgNS44aDFsOC4zIDY5Yy00LjIgMS4zLTcuNSA0LjctOC43IDguOXptMTE5LjgtMzEuNmwtOTMuOCAzMC45Yy0xLjgtNS4yLTYuNy04LjktMTIuNS05bC04LjQtNjkuNWMxLjgtLjggMy41LTIuMSA0LjgtMy42bDExMS4yIDQyLjNjLTEgMS45LTEuNSA0LTEuNSA2LjMtLjEuOSAwIDEuOC4yIDIuNnptLTEwNy41LTU1LjRsLS40LS4yaDc0LjFjLjQgNy4yIDYuMyAxMyAxMy43IDEzIDEuNCAwIDIuNy0uMiAzLjktLjZsMTguOCAyOS42LTExMC4xLTQxLjh6bTEyMS43IDM5LjJoLS44Yy0yLjIgMC00LjIuNS02IDEuNGwtMTkuNC0zMC42YzMuMy0yLjUgNS40LTYuNCA1LjQtMTAuOSAwLTIuMy0uNi00LjUtMS42LTYuNGw1OS45LTMxYy41IDEgMS4yIDEuOSAyIDIuN2wtMzkuNSA3NC44em0zNy41LTkwLjZsLTY0LjgtNTQuM2MuOS0xLjggMS40LTMuOSAxLjQtNi4xIDAtLjQgMC0uOC0uMS0xLjItLjEtMS44LS42LTMuNC0xLjQtNC45LTEuMi0yLjMtMy00LjMtNS4yLTUuNmwxNi40LTQyLjhjMS4zLjQgMi42LjYgNCAuNi45IDAgMS44LS4xIDIuNy0uM2w1MC40IDExMC42Yy0xLjQgMS4xLTIuNSAyLjQtMy40IDR6Ii8+PC9zdmc+" alt="" style="width: 24px; vertical-align: middle; position: relative; top: -1px;"> Torbara.com</a>');
    array_push($links, '<a title="Our portfolio on Envato Market" href="http://themeforest.net/user/torbara/portfolio?ref=torbara" target="_blank"><img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTkuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeD0iMHB4IiB5PSIwcHgiIHZpZXdCb3g9IjAgMCAzMDkuMjY3IDMwOS4yNjciIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDMwOS4yNjcgMzA5LjI2NzsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSI2NHB4IiBoZWlnaHQ9IjY0cHgiPgo8Zz4KCTxwYXRoIHN0eWxlPSJmaWxsOiNEMDk5NEI7IiBkPSJNMjYwLjk0NCw0My40OTFIMTI1LjY0YzAsMC0xOC4zMjQtMjguOTk0LTI4Ljk5NC0yOC45OTRINDguMzIzYy0xMC42NywwLTE5LjMyOSw4LjY1LTE5LjMyOSwxOS4zMjkgICB2MjIyLjI4NmMwLDEwLjY3LDguNjU5LDE5LjMyOSwxOS4zMjksMTkuMzI5aDIxMi42MjFjMTAuNjcsMCwxOS4zMjktOC42NTksMTkuMzI5LTE5LjMyOVY2Mi44MiAgIEMyODAuMjczLDUyLjE1LDI3MS42MTQsNDMuNDkxLDI2MC45NDQsNDMuNDkxeiIvPgoJPHBhdGggc3R5bGU9ImZpbGw6I0U0RTdFNzsiIGQ9Ik0yOC45OTQsNzIuNDg0aDI1MS4yNzl2NzcuMzE3SDI4Ljk5NFY3Mi40ODR6Ii8+Cgk8cGF0aCBzdHlsZT0iZmlsbDojRjRCNDU5OyIgZD0iTTE5LjMyOSw5MS44MTRoMjcwLjYwOWMxMC42NywwLDE5LjMyOSw4LjY1LDE5LjMyOSwxOS4zMjlsLTE5LjMyOSwxNjQuMjk4ICAgYzAsMTAuNjctOC42NTksMTkuMzI5LTE5LjMyOSwxOS4zMjlIMzguNjU4Yy0xMC42NywwLTE5LjMyOS04LjY1OS0xOS4zMjktMTkuMzI5TDAsMTExLjE0M0MwLDEwMC40NjMsOC42NTksOTEuODE0LDE5LjMyOSw5MS44MTR6ICAgIi8+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPGc+CjwvZz4KPC9zdmc+Cg==" alt="" style="width: 16px; vertical-align: middle; position: relative; top: -2px;"> Portfolio</a>');
    return $links;
};
add_filter( "plugin_action_links_".plugin_basename( __FILE__ ), $tt_f_plugin_links );