<div id="warp" class="wrap" data-warp="theme">

    <form id="theme-options" method="post" action="">

        <?php echo $this->render('config:layouts/config') ?>
    </form>

</div>
