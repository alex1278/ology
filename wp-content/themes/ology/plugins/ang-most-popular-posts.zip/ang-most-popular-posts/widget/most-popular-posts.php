<?php
/*
 * Plugin Name: ANG most popular posts
 * Plugin URI: http://karate.do-i-posle.dzu/
 * Description: Display Popular Posts by Views
 * Author: Aleksandr Glovatskyy
 * Author URI: http://karate.do-i-posle.dzu/
 * Author e-mail: alex1278@list.ru
 * Version: 1.0.0
 * Date: 24.12.2015
 * License: GPL2+
 * @subpackage  Widget
 */

class ANG_most_popular_posts extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    function __construct() {
        parent::__construct(
            'ang-most-popular-posts', // Base ID
            __('ANG Most Popular Posts', 'ang-plugins'), // Name
            array( 'description' => __( 'Display Popular Posts by Views', 'ang-plugins' ), ) // Args
        );
    }
    
    function form($instance) { ?>

<!--        Widget title -->

        <?php $title = isset( $instance['title']) ? esc_attr( $instance['title'] ) : ''; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
                <?php esc_html_e('Title:', 'ang-plugins'); ?>
                <input class="widefat" 
                        id="<?php echo esc_attr($this->get_field_id('title')); ?>" 
                        name="<?php echo esc_attr($this->get_field_name('title')); ?>" 
                        type="text" 
                        value="<?php echo esc_attr($title); ?>" />
            </label>
        </p>
        
        <!--        Description textarea -->
        
        <?php $descr = isset( $instance['descr']) ?  $instance['descr'] : ''; ?>
        <p>
            <label for="<?php echo $this->get_field_id('descr'); ?>">
                <?php esc_html_e('Description:', 'ang-plugins'); ?>
                <textarea class="widefat" rows="3" cols="10" 
                        id="<?php echo $this->get_field_id('descr'); ?>" 
                        name="<?php echo $this->get_field_name('descr'); ?>"><?php echo $descr; ?></textarea>
            </label>
        </p>
        
         <!--   Checkox Disable description output -->
         
         <?php $descr_disable = isset( $instance['descr_disable'] ) ? $instance['descr_disable'] : false; ?>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('descr_disable'); ?>" name="<?php echo $this->get_field_name('descr_disable'); ?>" <?php if ($descr_disable) echo 'checked'; ?> />
            <label for="<?php echo $this->get_field_id('descr_disable'); ?>"><?php esc_html_e('Disable description output', 'ang-plugins'); ?></label>
        </p>
            
        
        <!--   ADD Extra class -->
        
        <?php $extra_class = isset( $instance['extra_class']) ? esc_attr( $instance['extra_class'] ) : ''; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('extra_class')); ?>">
                <?php esc_html_e('Extra class:', 'ang-plugins'); ?>
                <input class="widefat" 
                        id="<?php echo esc_attr($this->get_field_id('extra_class')); ?>" 
                        name="<?php echo esc_attr($this->get_field_name('extra_class')); ?>" 
                        type="text" 
                        value="<?php echo esc_attr($extra_class); ?>" />
            </label>
        </p>
        
        <!--     Returns all registered post types-->
            
    <?php $p_post_type = isset( $instance['p_post_type'] ) ? $instance['p_post_type'] : 'post'; ?>
        <p>
            <label for="<?php echo $this->get_field_id('p_post_type'); ?>">
                <?php esc_html_e('Select post type:', 'ang-plugins'); ?>
                <?php
                    $args=array(
                                'public'   => true,
                              );
                $post_types = get_post_types($args,'names'); 
                
                ?><select class="widefat" 
                          id="<?php echo esc_attr($this->get_field_id('p_post_type')); ?>" 
                          name="<?php echo esc_attr($this->get_field_name('p_post_type')); ?>" >
                <?php foreach ($post_types as $post_type){ ?>
                    <option value="<?php echo esc_attr($post_type); ?>" <?php if($post_type==$p_post_type){echo 'selected=""';} ?>><?php echo $post_type; ?></option>
                <?php } ?>
                </select>
            </label>
        </p>
        
<!--        Selecting category id-->
        <?php $CatID = isset( $instance['CatID'] ) ? $instance['CatID'] : ''; ?>
         <p>
            <label for="<?php echo $this->get_field_id('CatID'); ?>">
                <?php esc_html_e('Post Category:', 'ang-plugins'); ?>
                    <?php
  
                $args = array(
                    'type'                     => 'post',
                    'child_of'                 => 0,
                    'parent'                   => '',
                    'orderby'                  => 'name',
                    'order'                    => 'ASC',
                    'hide_empty'               => 1,
                    'hierarchical'             => 1,
                    'exclude'                  => '',
                    'include'                  => '',
                    'number'                   => '',
                    'taxonomy'                 => 'category',
                    'pad_counts'               => false 
                );
                
                $cats = get_categories( $args );
                
                ?><select class="widefat" 
                          id="<?php echo esc_attr($this->get_field_id('CatID')); ?>" 
                          name="<?php echo esc_attr($this->get_field_name('CatID')); ?>" >
                    <option value='' <?php if('' == $CatID){echo 'selected=""';} ?>><?php esc_html_e('--All Posts--', 'ang-plugins'); ?></option>
         
            <?php   foreach ($cats as $cat){ ?>
                    <option value="<?php echo esc_attr($cat->term_id); ?>" <?php if($cat->term_id == $CatID){echo 'selected=""';} ?>><?php echo $cat->name; ?></option>
            <?php } ?>
                </select>
            </label>
        </p>
       

        <!--        Type a number of items-->

        <?php $PostsCount1 = isset( $instance['PostsCount1'] ) ? $instance['PostsCount1'] : 6; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('PostsCount1')); ?>">
                <?php esc_html_e('Number of items:', 'ang-plugins'); ?>
                <input class="widefat" 
                        id="<?php echo esc_attr($this->get_field_id('PostsCount1')); ?>" 
                        name="<?php echo esc_attr($this->get_field_name('PostsCount1')); ?>" 
                        type="number"
                        min ="-1"
                        value="<?php echo esc_attr($PostsCount1); ?>" />
            </label>
        </p>
        
        <!--        Number of words per post -->
        
        <?php $p_number_words1 = isset( $instance[ 'p_number_words1' ] ) ? $instance[ 'p_number_words1' ] : 30; ?>
        <p>
            <label for="<?php echo $this->get_field_id('p_number_words1'); ?>">
                <?php esc_html_e('Words per each post:', 'ang-plugins'); ?>
                <input class="widefat" 
                        id="<?php echo $this->get_field_id('p_number_words1'); ?>" 
                        name="<?php echo $this->get_field_name('p_number_words1'); ?>" 
                        type="number"
                        min="5"
                        value="<?php echo esc_attr($p_number_words1); ?>" />
            </label>
        </p>
        
        <!--        Select image size-->
        <?php $image_size = isset( $instance[ 'image_size' ] ) ? $instance[ 'image_size' ] : ''; ?>
        
        <p>
            <label for="<?php echo $this->get_field_id('image_size'); ?>">Image Size: </label>
            <select class="widefat" id="<?php echo $this->get_field_id('image_size'); ?>" name="<?php echo $this->get_field_name('image_size'); ?>">
                <option class="widefat" value="" <?php if('' == $image_size){echo 'selected="selected"';} ?>><?php esc_html_e('--Default (80 X 80)--', 'ang-plugins'); ?></option>
                <?php
                    $sizes = ang_get_thumbnail_sizes();
                    foreach ($sizes as $k=>$v) {
                            $v = implode(" x ", $v);
                            echo '<option class="widefat" value="' . $k . '" id="' . $k . '"', $image_size == $k ? ' selected="selected"' : '', '>'. $k .' '. $v. '</option>';
                    }
                ?>
            </select>
        </p>
                
         <!--   Checkox Hide the featured image -->
         
        <?php $p_image = isset( $instance['p_image'] ) ? $instance['p_image'] : false; ?>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('p_image'); ?>" name="<?php echo $this->get_field_name('p_image'); ?>" <?php if ($p_image) echo 'checked'; ?> />
            <label for="<?php echo $this->get_field_id('p_image'); ?>"><?php esc_html_e('Hide the featured image', 'ang-plugins'); ?></label>
        </p>
               
        <!--   Checkox Hide the post title -->
         
         <?php $p_title1 = isset( $instance['p_title1'] ) ? $instance['p_title1'] : false; ?>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('p_title1'); ?>" name="<?php echo $this->get_field_name('p_title1'); ?>" <?php if ($p_title1) echo 'checked'; ?> />
            <label for="<?php echo $this->get_field_id('p_title1'); ?>"><?php esc_html_e('Hide the post title', 'ang-plugins'); ?></label>
        </p>
        <!--   Checkox Hide the views count-->
         
         <?php $p_views = isset( $instance['p_views'] ) ? $instance['p_views'] : false; ?>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('p_views'); ?>" name="<?php echo $this->get_field_name('p_views'); ?>" <?php if ($p_views) echo 'checked'; ?> />
            <label for="<?php echo $this->get_field_id('p_views'); ?>"><?php esc_html_e('Hide views count', 'ang-plugins'); ?></label>
        </p>
        
        <!--   Checkox Hide the post excerpt -->
         
         <?php $p_excerpt1 = isset( $instance['p_excerpt1'] ) ? $instance['p_excerpt1'] : false; ?>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('p_excerpt1'); ?>" name="<?php echo $this->get_field_name('p_excerpt1'); ?>" <?php if ($p_excerpt1) echo 'checked'; ?> />
            <label for="<?php echo $this->get_field_id('p_excerpt1'); ?>"><?php esc_html_e('Hide the post excerpt', 'ang-plugins'); ?></label>
        </p>
        
        <!--   Order type -->
        
        <?php $p_order_type = isset( $instance['p_order_type'] ) ? $instance['p_order_type'] : "DESC"; ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id( 'p_order_type' )); ?>">
                <?php esc_html_e('Posts order type:', 'ang-plugins'); ?>
            </label> 
            <br>
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('p_order_type')."_DESC"); ?>" name="<?php echo esc_attr($this->get_field_name('p_order_type')); ?>" value="DESC" <?php if($p_order_type=="DESC"){ echo "checked"; }?>><?php esc_html_e('DESC', 'ang-plugins'); ?>
            <input type="radio" id="<?php echo esc_attr($this->get_field_id('p_order_type')."_ASC"); ?>" name="<?php echo esc_attr($this->get_field_name('p_order_type')); ?>" value="ASC" <?php if($p_order_type=="ASC"){ echo "checked"; }?>><?php esc_html_e('ASC', 'ang-plugins'); ?>
        </p>

        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['descr'] = $new_instance['descr'];
        $instance['descr_disable'] = $new_instance['descr_disable'];
        $instance['extra_class'] = $new_instance['extra_class'];
        $instance['p_post_type'] = $new_instance['p_post_type'];
        $instance['CatID'] = $new_instance['CatID'];
        $instance['PostsCount1'] = $new_instance['PostsCount1'];
        
        $instance['p_number_words1'] = $new_instance['p_number_words1'];
        $instance['image_size'] = $new_instance['image_size'];
        $instance['p_order_type'] = $new_instance['p_order_type'];
        $instance['p_image'] = $new_instance['p_image'];
        $instance['p_title1'] = $new_instance['p_title1'];
        $instance['p_views'] = $new_instance['p_views'];
        $instance['p_excerpt1'] = $new_instance['p_excerpt1'];
        
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);

        echo $before_widget;
        $title = empty($instance['title']) ? ' ' : apply_filters('widget_title', $instance['title']);

        if (!empty($title)) {
            echo $before_title . $title . $after_title;
        }
        
        $descr_disable = $instance['descr_disable'] ? true : false;
        $p_image = $instance['p_image'] ? true : false;
        $p_title1 = $instance['p_title1'] ? true : false;
        $p_views = $instance['p_views'] ? true : false;
        $p_excerpt1 = $instance['p_excerpt1'] ? true : false;
        $image_size = $instance['image_size'] ? $instance['image_size'] : array(80, 80);
       
        $epl_posts = array('property', 'land', 'commercial', 'business', 'commercial_land', 'rental', 'rural');
        
        $args = array(
            'post_type'             => $instance['p_post_type'],
            'posts_per_page'        => $instance['PostsCount1'],
            'meta_key'              => 'ang_post_views_count',
            'orderby'               => 'meta_value_num',
            'order'                 => $instance['p_order_type'],
            'ignore_sticky_posts'   => true,
            'post_status'           => 'publish',
        );
        
        // Check Post type post and category
        if($instance['p_post_type'] == 'post'){
           $args['cat'] = $instance['CatID'];
        }
        $plugin_dir = untrailingslashit(plugin_dir_url( __FILE__ ));
        $item = new WP_Query( $args );?>
       
    <div class="ang-most-popular-wrapp <?php if($instance['extra_class'] !='') echo $instance['extra_class']; ?>">
        <?php if($instance['descr'] != NULL && $descr_disable != true ) : ?>
        <div class="ang-slideshow-descr">
            <div class="uk-width-1-1 tm-widget-descr">
                <?php echo do_shortcode($instance['descr']); ?>
            </div>
        </div>
        <?php endif; ?>
        <div class="ang-most-popular">
            <?php if ( $item->have_posts() ) :
                
            $count=0; ?>
            <ul class="uk-grid uk-grid-width-1-1">
                <?php   while ( $item->have_posts() ) :
                                $item->the_post(); 
                                global $post; ?>
                <?php  $count++; $post_type = $post->post_type;
                            $categories = get_the_category($post->ID); ?>
                <li class="<?php echo 'num-'.$count;?> post-<?php echo 'post-'.$post->ID; ?> <?php echo 'p_type-'.$post->post_type;?> <?php if($instance['p_post_type'] == 'post') echo 'cat-name-'.$categories[0]->cat_name; ?>">
                    <div class="uk-nbfc">
                    <?php   
                        if ($p_image != true){ ?>
                        <div class="uk-margin-small-bottom uk-float-left ang-popular-img">
                            <figure class="uk-overlay uk-overlay-hover">
                        <?php if (has_post_thumbnail()){ ?>            
                                <?php echo get_the_post_thumbnail ($post->ID, $image_size, array('class' => 'tm-timeline-thumb uk-overlay-scale')); ?>
                                <?php 
                            }else{ ?>
                            <img class="ang-no-image uk-overlay-scale" alt="imgo" width="80px" height="80px" src="<?php echo $plugin_dir ;?>/img/imgo-400x400.jpg" />
                      <?php } ?>
                                <div class="uk-overlay-panel uk-overlay-fade uk-overlay-background uk-overlay-icon"></div>
                                <a class="uk-position-cover" href="<?php the_permalink(); ?>"></a>
                            </figure>
                        </div>
                    <?php  } ?>

                        <div class="uk-float-left ang-popular-info <?php if ($p_image == true) echo 'uk-width-1-1'; ?>">
                            <div class="">
                            <?php if($p_title1 != true){ ?>
                                <h5 class="">
                                    <a class="" href="<?php the_permalink(); ?>">
                                    <?php if (in_array($post->post_type, $epl_posts)) {
                                        echo get_post_meta( get_the_ID(), 'property_heading', true );
                                        }else{
                                            the_title();
                                        } ?>
                                    </a>
                                </h5>

                            <?php  } ?>

                            <?php   if ( $p_excerpt1 != true){
                                        if ( get_the_excerpt() != ''){
                                            echo '<p>'. wp_trim_words(get_the_excerpt(), $instance['p_number_words1'], '') .'</p>';
                                        } else {
                                            echo '<p>'. wp_trim_words(get_the_content(), $instance['p_number_words1'], '') .'</p>';
                                        } 
                                    }
                                    ?>
                            </div>
                            <div class="ang-popular-meta uk-grid-small uk-flex uk-flex-wrap uk-flex-space-between"  data-uk-grid-margin>
                                <div><time datetime="<?php echo get_the_date('Y-m-d');?>"><?php echo get_the_date('j M Y');?></time></div>
                                <?php if ( $p_views != true){ ?>
                                    <div><?php echo ang_get_post_views(get_the_ID()); ?></div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </li>
                <?php endwhile ;?>
            </ul>
            <?php endif;
            wp_reset_postdata(); ?>
        </div>
    </div>
    <?php
        echo $after_widget;
    }

}

add_action('widgets_init', create_function('', 'return register_widget("ANG_most_popular_posts");'));
