<?php
/**
 * 
 * @package     iBloga
 * @encoding    UTF-8
 * @version     1.1.0
 * @subpackage  Sorting filters
 * @copyright   Copyright (c) 2016, Aleksandr Glovatskyy
 * author       Aleksandr Glovatskyy, aleksandr1278@gmail.com
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @date        16.02.2016
 * @support     support@torbara.com
 */


// Sorting filters on front-end
// Create columns
function ang_custom_sorting_filter(){ 
    //if($query->is_main_query()){ ?> 
    <div class="uk-grid uk-grid-width-1-1">
        <div class="ang-post-filters-wrap">
            <form class="ang-post-filters"> 
                <span><?php esc_html_e('Sort by:', 'ang-plugins'); ?></span>
                <select name="orderby" onchange="this.form.submit()">
                        <?php
                                $orderby_options = array(
                                        'post_date'             => 'Date',
                                        'post_title'            => 'Title',
                                        'author'                => 'Author',
                                        'rand'                  => 'Random',
                                        'modified'              => 'Last Updated',
                                        'comment_count'         => 'Most Commented',

                                );
                                $keys_by = array_keys($orderby_options);
                                (isset($_GET["orderby"]) && !empty($_GET["orderby"])) ? $options = $_GET["orderby"] : $options = $keys_by[0];
                                foreach( $orderby_options as $value => $label ) { ?>
                                        <option <?php if($options == $value) echo 'selected="selected"';?> value='<?php echo $value; ?>'><?php echo $label;?> </option>
                                        <?php
                                }
                        ?>
                </select>
                <select name="order" onchange="this.form.submit()">
                        <?php
                                $order_options = array(
                                        'DESC'       => 'Descending',
                                        'ASC'        => 'Ascending',
                                );
                                $keys_order = array_keys($order_options);
                                (isset($_GET["order"]) && !empty($_GET["order"])) ? $options = $_GET["order"] : $options = $keys_order[0];
                                foreach( $order_options as $value => $label ) { ?>
                                        <option <?php if($options == $value) echo 'selected="selected"';?> value='<?php echo $value; ?>'><?php echo $label;?> </option>
                                        <?php
                                }
                        ?>
                </select>
                <select name="custom_meta" onchange="this.form.submit()">
                        <?php
                                $custom_meta_options = array(
                                        'all'                   => 'All Posts',
                                        'only_thumbnailed'      => 'With Thumbnails',
                                        'ang_post_views_count'  => 'Popularity',
                                        'sticky_posts'          => 'Featured',
                                );
                                $keys_thumb = array_keys($custom_meta_options);
                                (isset($_GET["custom_meta"]) && !empty($_GET["custom_meta"])) ? $options = $_GET["custom_meta"] : $options = $keys_thumb[0];
                                foreach( $custom_meta_options as $value => $label ) { ?>
                                        <option <?php if($options == $value) echo 'selected="selected"';?> value='<?php echo $value; ?>'><?php echo $label;?> </option>
                                        <?php

                                }
                        ?>
                </select>
                <!--<input type='submit' value='Filter!'>-->
            </form>
        </div>
    </div>

    <?php
    // Create new query args for custom sorting filters
    // Apply sorting filter to main query
        global $wp_query;
        $modifications = array();
        if( !empty($_GET["custom_meta"])){
            if($_GET['custom_meta'] == 'only_thumbnailed' ) {
                 $modifications['meta_query'][] = array(
                        'key' => '_thumbnail_id',
                        'value' => '',
                        'compare' => '!='
                );
            }
            if($_GET['custom_meta'] == 'ang_post_views_count' ) {
                    $modifications['meta_key'] = 'ang_post_views_count';
                    $modifications['orderby'] = 'meta_value_num';
            }
            if($_GET['custom_meta'] == 'sticky_posts' ) {
                $modifications['post__in']  = get_option( 'sticky_posts' );
                   
            }
               
        }
        
//        if( !empty($_GET["orderby"]) && $_GET['orderby'] == 'ang_post_views_count' ) {
//                $modifications['meta_key'] = 'ang_post_views_count';
//                $modifications['orderby'] = 'meta_value_num';
//        }

        $args = array_merge( $wp_query->query_vars, $modifications );

        $a = query_posts( $args );
        
       //var_dump($modifications);
        
//}
}
add_action('ang_custom_sorting_filter','ang_custom_sorting_filter');
//add_filter('loop_start', 'ang_custom_sorting_filter');
    