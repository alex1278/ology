<?php
/**
 * The plugin bootstrap file
 * Plugin Name: ANG Most popular post
 * Plugin URI: http://themeforest.net/user/torbara/?ref=torbara
 * Description: ANG Most popular post
 * Author: Aleksandr Glovatskyy
 * Author URI: http://themeforest.net/user/torbara/portfolio/?ref=torbara
 * Author e-mail: alex1278@list.ru
 * Version: 1.2.1
 * Date: 26.11.2015
 * License: GPL2+
 */

// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

// Script version, used to add version for scripts and styles
define( 'MPANG_VER', '1.0.0' );

// Define Plugin paths, for esta function files
if ( ! defined( 'MPANG_PLUGIN_DIR' ) )
        define( 'MPANG_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
    define( 'MPANG_WIDGET_DIR', trailingslashit( MPANG_PLUGIN_DIR . 'widget' ) );
    define( 'MPANG_ACTION_DIR', trailingslashit( MPANG_PLUGIN_DIR . 'action' ) );
    
    // widgets path
    foreach ( glob( MPANG_WIDGET_DIR . '*.php' ) as $widget )
    {	require_once $widget;       }
    // action path
    foreach ( glob( MPANG_ACTION_DIR . '*.php' ) as $action )
    {	require_once $action;       }

// The function will detect post views count and store it as a custom field for each post
function ang_set_post_views($postID) {
    $count_key = 'ang_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

//we need to call this function on the single post pages
function ang_track_post_views ($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;    
    }
    ang_set_post_views($post_id);
}
add_action( 'wp_head', 'ang_track_post_views');


// If you want to display the post view count on your single post pages.
// Inside your post loop add the following code:
//	ang_get_post_views(get_the_ID());


function ang_get_post_views($postID){
    $count_key = 'ang_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return 'Views <span class="views-num">0</span>';
    }
    return 'Views <span class="views-num">'.$count.'</span>';
}

/**
 * Used in the widgets by appending the registered image sizes
 *
 * @since 1.0
 */
if (!function_exists('ang_get_thumbnail_sizes')){
    
    function ang_get_thumbnail_sizes() {
            global $_wp_additional_image_sizes;
            $sizes = array();
            foreach( get_intermediate_image_sizes() as $s ) {
                    $sizes[ $s ] = array( 0, 0 );
                    if( in_array( $s, array( 'thumbnail', 'medium', 'large' ) ) ) {
                            $sizes[ $s ][0] = get_option( $s . '_size_w' );
                            $sizes[ $s ][1] = get_option( $s . '_size_h' );
                    } else {
                            if( isset( $_wp_additional_image_sizes ) && isset( $_wp_additional_image_sizes[ $s ] ) ) {
                                    $sizes[ $s ] = array( $_wp_additional_image_sizes[ $s ]['width'], $_wp_additional_image_sizes[ $s ]['height'], );
                            }
                    }
            }
            return $sizes;
    }
}