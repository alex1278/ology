<?php

/*
 * small actions
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;
