# ANG Commando Staff team

# Description #

The plugin created specially to introduce your team. This plugin generates the 'commando' custom post type with extra meta fields to your WordPress blog.

Working demos are available here:

**[LIVE DEMO Esta](http://w-esta.torbara.com/)**

**[LIVE DEMO Renter](http://renter.ninja.bget.ru/)**
