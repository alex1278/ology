<?php
/*
 * The plugin bootstrap file
 * 
 * Plugin Name: ANG Mega Slide
 * Plugin URI: http://themeforest.net/user/torbara/?ref=torbara
 * Description: Displays random posts in slideshow with thumbnail navigation and multiple select. Two widgets included.
 * Author: Aleksandr Glovatskyy
 * Author URI: http://themeforest.net/user/torbara/portfolio/?ref=torbara
 * Author e-mail: alex1278@list.ru
 * Version: 1.0.0
 * Date: 05.08.2016
 * License: GPL2+
 */


// Prevent loading this file directly
defined( 'ABSPATH' ) || exit;

// Script version, used to add version for scripts and styles
define( 'ANGS_VER', '1.0.0' );


/****************************  ang  ************************/

// Defines plugin base name // my-plugin/my-plugin.php.

$esta_plugin_path = untrailingslashit(plugin_dir_path( __FILE__ ));
if ( ! defined( 'ANGS_PLUGIN_BASE_NAME' ) )
define('ANGS_PLUGIN_BASE_NAME', plugin_basename(__FILE__));

// Define plugin URLs, for fast enqueuing scripts and styles
if ( ! defined( 'ANGS_PLUGIN_URL' ) )
	define( 'ANGS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ANGS_WGT_URL', trailingslashit( ANGS_PLUGIN_URL . 'widgets' ) );

// Define Plugin paths, for esta function files
if ( ! defined( 'ANGS_PLUGIN_DIR' ) )
	define( 'ANGS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ANGS_WGT_DIR', trailingslashit( ANGS_PLUGIN_DIR . 'widgets' ) );

// Registering widgets
foreach ( glob( ANGS_WGT_DIR . '*.php' ) as $widget )
{       require_once $widget;    }


/*********** 
 ******* apply for style dir
  *****/ 

function wp_load_ang_megaslide_css() {
    $plugin_url = plugin_dir_url( __FILE__ );

    wp_enqueue_style('css-ang-megaslide', $plugin_url . 'widgets/css/ang-megaslide.css' );
}
add_action('wp_enqueue_scripts', 'wp_load_ang_megaslide_css' );
// add category support for pages



/**************** 
 ********** Register taxpnomy for custom post type "Timeline"
 ****************/

if ( ! function_exists( 'custom_taxonomy_slideset' ) ) {

// Register Custom Taxonomy
function custom_taxonomy_slideset() {

	$labels = array(
		'name'                       => _x( 'Slidesets', 'Taxonomy General Name', 'ang-plugins' ),
		'singular_name'              => _x( 'Slideset', 'Taxonomy Singular Name', 'ang-plugins' ),
		'menu_name'                  => __( 'Slidesets', 'ang-plugins' ),
		'all_items'                  => __( 'All Slidesets', 'ang-plugins' ),
		'parent_item'                => __( 'Parent Slideset', 'ang-plugins' ),
		'parent_item_colon'          => __( 'Parent Slideset:', 'ang-plugins' ),
		'new_item_name'              => __( 'New Slideset Name', 'ang-plugins' ),
		'add_new_item'               => __( 'Add New Slideset', 'ang-plugins' ),
		'edit_item'                  => __( 'Edit Slideset', 'ang-plugins' ),
		'update_item'                => __( 'Update Slideset', 'ang-plugins' ),
		'view_item'                  => __( 'View Slideset', 'ang-plugins' ),
		'separate_items_with_commas' => __( 'Separate Slidesets with commas', 'ang-plugins' ),
		'add_or_remove_items'        => __( 'Add or remove Slidesets ', 'ang-plugins' ),
		'choose_from_most_used'      => __( 'Choose from the most used', 'ang-plugins' ),
		'popular_items'              => __( 'Popular Slidesets', 'ang-plugins' ),
		'search_items'               => __( 'Search Slidesets', 'ang-plugins' ),
		'not_found'                  => __( 'Not Found', 'ang-plugins' ),
		'items_list'                 => __( 'Slidesets list', 'ang-plugins' ),
		'items_list_navigation'      => __( 'Slidesets list navigation', 'ang-plugins' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'slideset', array( 'slideshow' ), $args );

}
add_action( 'init', 'custom_taxonomy_slideset', 0 );

}


/**************** 
 **********register new custom post type "Slideshow"
 ****************/

if ( ! function_exists('custom_post_type_slideshow') ) {

// Register Custom Post Type
function custom_post_type_slideshow() {

	$labels = array(
		'name'                  => _x( 'Slideshows', 'Post Type General Name', 'ang-plugins' ),
		'singular_name'         => _x( 'Slideshow', 'Post Type Singular Name', 'ang-plugins' ),
		'menu_name'             => __( 'Slideshow', 'ang-plugins' ),
		'name_admin_bar'        => __( 'Slideshow', 'ang-plugins' ),
		'parent_item_colon'     => __( 'Parent Item:', 'ang-plugins' ),
		'all_items'             => __( 'All Slides', 'ang-plugins' ),
		'add_new_item'          => __( 'Add New Slide', 'ang-plugins' ),
		'add_new'               => __( 'Add New', 'ang-plugins' ),
		'new_item'              => __( 'Slide', 'ang-plugins' ),
		'edit_item'             => __( 'Edit Slide', 'ang-plugins' ),
		'update_item'           => __( 'Update Slide', 'ang-plugins' ),
		'view_item'             => __( 'View Slide', 'ang-plugins' ),
		'search_items'          => __( 'Search Slide', 'ang-plugins' ),
		'not_found'             => __( 'Slide Not found', 'ang-plugins' ),
		'not_found_in_trash'    => __( 'Slide Not found in Trash', 'ang-plugins' ),
		'items_list'            => __( 'Slides list', 'ang-plugins' ),
		'items_list_navigation' => __( 'Slides list navigation', 'ang-plugins' ),
		'filter_items_list'     => __( 'Filter Slides list', 'ang-plugins' ),
	);
	$args = array(
		'label'                 => __( 'Slideshow', 'ang-plugins' ),
		'description'           => __( 'Every post will be displayed like slideshow', 'ang-plugins' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', ),
		'taxonomies'            => array('slideset'),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 13,
                'menu_icon'             => 'dashicons-images-alt2',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
	);
	register_post_type( 'slideshow', $args );

}
add_action( 'init', 'custom_post_type_slideshow', 0 );
}



    /*
     * add theme support post thumbnails in slideshow listing for admin
     */
add_filter('manage_edit-slideshow_columns', 'slideshow_listing', 5);
function slideshow_listing($default1) {
    $default1['post_thumbnails'] = 'Slide';
    return $default1;
}
 
//image size
add_action('manage_slideshow_posts_custom_column', 'slideshow_custom_columns', 5, 2);
function slideshow_custom_columns($row_label, $id) {
    if ($row_label === 'post_thumbnails') :
        print the_post_thumbnail(array(100,100));
    endif;
}

// sortable columns
add_filter('manage_edit-slideshow_sortable_columns', 'add_slideshow_sortable_column');
function add_slideshow_sortable_column($sortable_columns){
	$sortable_columns['post_thumbnails'] = 'Slide';

	return $sortable_columns;
}