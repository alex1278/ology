<?php
/*
 * Ordinary WP pagination
 */
if (!function_exists('ang_ordinary_wp_pagination')) {
    function ang_ordinary_wp_pagination($wp_query) {
            //global $wp_query;
            $pages = '';
            $max = $wp_query->max_num_pages;
            if (!$current = get_query_var('paged')) $current = 1;
            $a['base'] = str_replace(999999999, '%#%', get_pagenum_link(999999999));
            $a['total'] = $max;
            $a['current'] = $current;

            $total = 1; //1 - выводить текст "Страница N из N", 0 - не выводить
            $a['mid_size'] = 3; //сколько ссылок показывать слева и справа от текущей
            $a['end_size'] = 1; //сколько ссылок показывать в начале и в конце
            $a['prev_text'] = '&laquo;'; //текст ссылки "Предыдущая страница"
            $a['next_text'] = '&raquo;'; //текст ссылки "Следующая страница"

            if ($max > 1) echo '<div class="navigation">';
            if ($total == 1 && $max > 1) $pages = '<span class="pages">Page ' . $current . ' of ' . $max . '</span>'."\r\n";
            echo $pages . paginate_links($a);
            if ($max > 1) echo '</div>';
    }
    // you should set 1 extra param when call action ($wp_query)
    add_action('ordinary_pagination','ang_ordinary_wp_pagination', 1);
}

/*
 * Ordinary WP pagination fro twentyfourteen
 */
if (!function_exists('ang_wp_pagination')) {
    function ang_wp_pagination() {
        global $wp_query, $wp_rewrite;
	if ($wp_query->max_num_pages < 2) {
            return;
        }

        $paged = get_query_var('paged') ? intval(get_query_var('paged')) : 1;
        $pagenum_link = html_entity_decode(get_pagenum_link());
        $query_args = array();
        $url_parts = explode('?', $pagenum_link);

        if (isset($url_parts[1])) {
            wp_parse_str($url_parts[1], $query_args);
        }

        $pagenum_link = remove_query_arg(array_keys($query_args), $pagenum_link);
        $pagenum_link = trailingslashit($pagenum_link) . '%_%';

        $format = $wp_rewrite->using_index_permalinks() && !strpos($pagenum_link, 'index.php') ? 'index.php/' : '';
        $format .= $wp_rewrite->using_permalinks() ? user_trailingslashit($wp_rewrite->pagination_base . '/%#%', 'paged') : '?paged=%#%';

        // Set up paginated links.
        $links = paginate_links(array(
            'base' => $pagenum_link,
            'format' => $format,
            'total' => $wp_query->max_num_pages,
            'current' => $paged,
            'mid_size' => 1,
            'add_args' => array_map('urlencode', $query_args),
            'prev_text' => '<i class="prev"></i>' . '<span>' . esc_html__('Previous', 'ang-plugins') . '</span>',
            'next_text' => '<span>' . esc_html__('Next', 'ang-plugins') . '</span>' . '<i class="next"></i>',
        ));

        if ($links){
            print "<nav class='navigation paging-navigation'>
                    <div class='pagination loop-pagination>{$links}</div>
                    </nav>";
        }
    }
}
add_action('ang_wp_pagination','ang_wp_pagination');